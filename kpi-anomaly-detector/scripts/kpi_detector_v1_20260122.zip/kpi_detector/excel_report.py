# -*- coding: utf-8 -*-
"""
Excel Report Generator Module
Generates Excel reports with multiple analysis sheets
"""

import numpy as np
import pandas as pd
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from pathlib import Path
from typing import Dict, Any, Optional

from .config import COLORS
from .utils import generate_sparkline


class ExcelReportGenerator:
    """Generate Excel analysis reports"""
    
    def __init__(self, output_dir: Path):
        """Initialize report generator
        
        Args:
            output_dir: Directory for output files
        """
        self.output_dir = output_dir
        self._init_styles()
    
    def _init_styles(self):
        """Initialize Excel styles"""
        self.header_fill = PatternFill(start_color=COLORS['header'], end_color=COLORS['header'], fill_type="solid")
        self.header_font = Font(bold=True, color="FFFFFF")
        self.header_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        
        self.critical_fill = PatternFill(start_color=COLORS['critical'], end_color=COLORS['critical'], fill_type="solid")
        self.suspicious_fill = PatternFill(start_color=COLORS['suspicious'], end_color=COLORS['suspicious'], fill_type="solid")
        self.warning_fill = PatternFill(start_color=COLORS['warning'], end_color=COLORS['warning'], fill_type="solid")
        self.caution_fill = PatternFill(start_color=COLORS['caution'], end_color=COLORS['caution'], fill_type="solid")
        self.normal_fill = PatternFill(start_color=COLORS['normal'], end_color=COLORS['normal'], fill_type="solid")
        self.improved_fill = PatternFill(start_color=COLORS['improved'], end_color=COLORS['improved'], fill_type="solid")
        self.worsened_fill = PatternFill(start_color=COLORS['worsened'], end_color=COLORS['worsened'], fill_type="solid")
        
        self.thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
    
    def generate(self, filename: str, analysis_results: Dict[str, Any], 
                 comparison: Optional[Dict] = None,
                 history_records: list = None,
                 current_record: Dict = None) -> Path:
        """Generate Excel report
        
        Args:
            filename: Base filename (without extension)
            analysis_results: Analysis results dictionary
            comparison: Comparison with history
            history_records: List of historical records
            current_record: Current analysis record
            
        Returns:
            Path to generated report file
        """
        output_file = self.output_dir / f"{filename}_analysis_report.xlsx"
        
        wb = openpyxl.Workbook()
        wb.remove(wb.active)
        
        consistency_df = analysis_results.get('consistency', pd.DataFrame())
        ttest_df = analysis_results.get('ttest', pd.DataFrame())
        suspicious_df = analysis_results.get('suspicious', pd.DataFrame())
        
        # Create sheets
        self._create_summary_sheet(wb, filename, consistency_df, suspicious_df, ttest_df, comparison)
        self._create_suspicious_sheet(wb, suspicious_df)
        self._create_changes_sheet(wb, comparison, consistency_df)
        self._create_history_sheet(wb, history_records or [], current_record)
        self._create_consistency_sheet(wb, consistency_df, comparison)
        self._create_ttest_sheet(wb, ttest_df)
        self._create_verification_sheet(wb, consistency_df, suspicious_df, ttest_df)
        
        wb.save(output_file)
        print(f"Report saved to: {output_file}")
        
        return output_file
    
    def _create_summary_sheet(self, wb, filename, consistency_df, suspicious_df, ttest_df, comparison):
        """Create summary sheet"""
        ws = wb.create_sheet(title='1_Summary')
        
        current_row = 1
        
        # Title
        ws.cell(row=current_row, column=1, value='KPI Anomaly Detection Report')
        ws.cell(row=current_row, column=1).font = Font(bold=True, size=16)
        current_row += 2
        
        # File info
        ws.cell(row=current_row, column=1, value='Analysis File')
        ws.cell(row=current_row, column=2, value=filename)
        current_row += 1
        ws.cell(row=current_row, column=1, value='Analysis Time')
        ws.cell(row=current_row, column=2, value=pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'))
        current_row += 2
        
        # Consistency analysis section
        ws.cell(row=current_row, column=1, value='========== Consistency Analysis ==========')
        ws.cell(row=current_row, column=1).font = Font(bold=True)
        current_row += 2
        
        if not consistency_df.empty:
            kpi_df = consistency_df[consistency_df['Type'] == 'KPI']
            counter_df = consistency_df[consistency_df['Type'] == 'Counter']
            other_df = consistency_df[consistency_df['Type'] == 'Other']
            
            headers = ['', f'[Total] ({len(consistency_df)})', f'[KPI] ({len(kpi_df)})', f'[Counter] ({len(counter_df)})']
            if len(other_df) > 0:
                headers.append(f'[Other] ({len(other_df)})')
            
            for col_idx, header in enumerate(headers, start=1):
                cell = ws.cell(row=current_row, column=col_idx, value=header)
                cell.fill = self.header_fill
                cell.font = self.header_font
                cell.border = self.thin_border
                cell.alignment = Alignment(horizontal='center')
            current_row += 1
            
            status_list = ['Consistent', 'Inconsistent', 'partial NULL', 'NULL']
            for status in status_list:
                cons_status = self._map_consistency_status(status)
                row_data = [
                    f'  - {status}',
                    int((consistency_df['Consistency'] == cons_status).sum()),
                    int((kpi_df['Consistency'] == cons_status).sum()),
                    int((counter_df['Consistency'] == cons_status).sum()),
                ]
                if len(other_df) > 0:
                    row_data.append(int((other_df['Consistency'] == cons_status).sum()))
                
                for col_idx, value in enumerate(row_data, start=1):
                    cell = ws.cell(row=current_row, column=col_idx, value=value)
                    cell.border = self.thin_border
                    if col_idx > 1:
                        cell.alignment = Alignment(horizontal='center')
                    if status == 'Inconsistent' and col_idx > 1 and value > 0:
                        cell.fill = self.warning_fill
                current_row += 1
        
        current_row += 1
        
        # T-test statistics
        if not ttest_df.empty:
            ws.cell(row=current_row, column=1, value='========== T-Test Analysis (vs History) ==========')
            ws.cell(row=current_row, column=1).font = Font(bold=True)
            current_row += 2
            
            ws.cell(row=current_row, column=1, value='  - Pass')
            ws.cell(row=current_row, column=2, value=int((ttest_df['TTest_Result'] == 'Pass').sum()))
            current_row += 1
            ws.cell(row=current_row, column=1, value='  - Fail')
            cell = ws.cell(row=current_row, column=2, value=int((ttest_df['TTest_Result'] == 'Fail').sum()))
            if int((ttest_df['TTest_Result'] == 'Fail').sum()) > 0:
                cell.fill = self.critical_fill
                cell.font = Font(color="FFFFFF")
            current_row += 2
        
        # Comparison with history
        if comparison:
            ws.cell(row=current_row, column=1, value='========== Comparison with History ==========')
            ws.cell(row=current_row, column=1).font = Font(bold=True)
            current_row += 2
            
            compare_data = [
                ['Previous Analysis File', comparison['previous_file']],
                ['Previous Analysis Time', comparison['previous_time']],
                ['', ''],
                ['Inconsistent Count Change', f"{comparison['delta_inconsistent']:+d}"],
                ['New Inconsistent', len(comparison['new_inconsistent'])],
                ['Fixed', len(comparison['fixed'])],
                ['Persistent Inconsistent', len(comparison['persistent'])],
            ]
            
            for row_data in compare_data:
                ws.cell(row=current_row, column=1, value=row_data[0])
                cell = ws.cell(row=current_row, column=2, value=row_data[1])
                if 'Change' in str(row_data[0]):
                    try:
                        val = int(str(row_data[1]).replace('+', ''))
                        if val > 0:
                            cell.fill = self.worsened_fill
                        elif val < 0:
                            cell.fill = self.improved_fill
                    except:
                        pass
                current_row += 1
        
        # Set column widths
        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 18
        ws.column_dimensions['C'].width = 18
        ws.column_dimensions['D'].width = 18
        ws.column_dimensions['E'].width = 18
    
    def _map_consistency_status(self, status: str) -> str:
        """Map English status to stored value"""
        # The data still uses Chinese internally for compatibility
        mapping = {
            'Consistent': 'Consistent',
            'Inconsistent': 'Inconsistent',
            'partial NULL': 'partial NULL',
            'NULL': 'NULL'
        }
        return mapping.get(status, status)
    
    def _create_suspicious_sheet(self, wb, suspicious_df):
        """Create suspicious KPI sheet"""
        if suspicious_df.empty:
            return
        
        ws = wb.create_sheet(title='2_Suspicious_KPI')
        
        exclude_cols = ['_shewhart_chart']
        headers = [h for h in suspicious_df.columns.tolist() if h not in exclude_cols]
        
        if 'Current_Data' in headers:
            curr_idx = headers.index('Current_Data')
            headers.insert(curr_idx, 'Current_Sparkline')
        if 'History_Data' in headers:
            hist_idx = headers.index('History_Data')
            headers.insert(hist_idx, 'History_Sparkline')
        
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = self.header_fill
            cell.font = self.header_font
            cell.alignment = self.header_alignment
            cell.border = self.thin_border
        
        for row_idx, (_, row) in enumerate(suspicious_df.iterrows(), start=2):
            for col_idx, header in enumerate(headers, start=1):
                if header == 'Current_Sparkline':
                    raw_data = row['Current_Data']
                    sparkline = generate_sparkline(raw_data)
                    cell = ws.cell(row=row_idx, column=col_idx, value=sparkline)
                    cell.font = Font(name='Consolas', size=9)
                elif header == 'History_Sparkline':
                    history_data = row['History_Data']
                    sparkline = generate_sparkline(history_data)
                    cell = ws.cell(row=row_idx, column=col_idx, value=sparkline)
                    cell.font = Font(name='Consolas', size=9, color='808080')
                else:
                    value = row[header]
                    if pd.isna(value):
                        value = ''
                    elif isinstance(value, float) and not np.isfinite(value):
                        value = ''
                    elif isinstance(value, dict):
                        value = ''
                    cell = ws.cell(row=row_idx, column=col_idx, value=value)
                    
                    if header == 'Severity':
                        if value == 'Critical':
                            cell.fill = self.critical_fill
                            cell.font = Font(bold=True, color="FFFFFF")
                        elif value == 'Suspicious':
                            cell.fill = self.suspicious_fill
                            cell.font = Font(bold=True, color="FFFFFF")
                        elif value == 'Warning':
                            cell.fill = self.warning_fill
                    
                    if header == 'Consistency' and value == 'Inconsistent':
                        cell.fill = self.warning_fill
                    
                    if header == 'TTest_Result' and value == 'Fail':
                        cell.fill = self.critical_fill
                        cell.font = Font(color="FFFFFF")
        
        ws.freeze_panes = 'A2'
    
    def _create_changes_sheet(self, wb, comparison, consistency_df):
        """Create change tracking sheet"""
        if not comparison:
            return
        
        ws = wb.create_sheet(title='3_Change_Tracking')
        
        row = 1
        ws.cell(row=row, column=1, value='New Inconsistent (Need Attention)')
        ws.cell(row=row, column=1).font = Font(bold=True, size=12)
        ws.cell(row=row, column=1).fill = self.worsened_fill
        row += 1
        
        if comparison['new_inconsistent']:
            for code in comparison['new_inconsistent']:
                ws.cell(row=row, column=1, value=code)
                kpi_row = consistency_df[consistency_df['Code'] == code]
                if not kpi_row.empty:
                    ws.cell(row=row, column=2, value=kpi_row['KPI Name'].iloc[0])
                ws.cell(row=row, column=1).fill = self.worsened_fill
                row += 1
        else:
            ws.cell(row=row, column=1, value='(None)')
            row += 1
        
        row += 1
        
        ws.cell(row=row, column=1, value='Fixed (Improved)')
        ws.cell(row=row, column=1).font = Font(bold=True, size=12)
        ws.cell(row=row, column=1).fill = self.improved_fill
        row += 1
        
        if comparison['fixed']:
            for code in comparison['fixed']:
                ws.cell(row=row, column=1, value=code)
                ws.cell(row=row, column=1).fill = self.improved_fill
                row += 1
        else:
            ws.cell(row=row, column=1, value='(None)')
            row += 1
        
        row += 1
        
        ws.cell(row=row, column=1, value='Persistent Inconsistent (Need Follow-up)')
        ws.cell(row=row, column=1).font = Font(bold=True, size=12)
        ws.cell(row=row, column=1).fill = self.warning_fill
        row += 1
        
        if comparison['persistent']:
            for code in comparison['persistent']:
                ws.cell(row=row, column=1, value=code)
                kpi_row = consistency_df[consistency_df['Code'] == code]
                if not kpi_row.empty:
                    ws.cell(row=row, column=2, value=kpi_row['KPI Name'].iloc[0])
                ws.cell(row=row, column=1).fill = self.warning_fill
                row += 1
        else:
            ws.cell(row=row, column=1, value='(None)')
            row += 1
        
        ws.column_dimensions['A'].width = 20
        ws.column_dimensions['B'].width = 60
    
    def _create_history_sheet(self, wb, history_records, current_record):
        """Create history summary sheet"""
        ws = wb.create_sheet(title='4_History_Summary')
        
        hist_headers = ['No.', 'Filename', 'Analysis Time', 'Consistent', 'Inconsistent', 
                       'Inconsistent_KPI', 'Inconsistent_Counter', 
                       'Inconsistent_KPI_trimmed', 'Inconsistent_Counter_trimmed', 
                       'Partial NULL', 'NULL', 'Critical', 'Suspicious', 'Warning']
        
        for col_idx, header in enumerate(hist_headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = self.header_fill
            cell.font = self.header_font
            cell.alignment = self.header_alignment
            cell.border = self.thin_border
        
        all_records = history_records.copy() if history_records else []
        if current_record:
            all_records.append(current_record)
        
        for row_idx, record in enumerate(reversed(all_records), start=2):
            stats = record.get('stats', {})
            is_current = (record == current_record)
            data = [
                len(all_records) - row_idx + 2,
                record.get('filename', 'N/A'),
                record.get('timestamp', 'N/A'),
                stats.get('consistent', 0),
                stats.get('inconsistent', 0),
                stats.get('inconsistent_kpi', 0),
                stats.get('inconsistent_counter', 0),
                stats.get('inconsistent_kpi_trimmed', 0),
                stats.get('inconsistent_counter_trimmed', 0),
                stats.get('partial_null', 0),
                stats.get('null', 0),
                stats.get('suspicious_critical', 0),
                stats.get('suspicious_suspicious', 0),
                stats.get('suspicious_warning', 0),
            ]
            for col_idx, value in enumerate(data, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = self.thin_border
                if col_idx == 5 and value > 0:
                    cell.fill = self.warning_fill
                if col_idx in [8, 9] and value > 0:
                    cell.fill = self.critical_fill
                    cell.font = Font(color="FFFFFF")
                if is_current and col_idx <= 3:
                    cell.fill = PatternFill(start_color="CCE5FF", end_color="CCE5FF", fill_type="solid")
        
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 60
        ws.column_dimensions['C'].width = 20
        for col in 'DEFGHIJKLMN':
            ws.column_dimensions[col].width = 14
        
        ws.freeze_panes = 'A2'
    
    def _create_consistency_sheet(self, wb, consistency_df, comparison):
        """Create consistency details sheet"""
        if consistency_df.empty:
            return
        
        ws = wb.create_sheet(title='5_Consistency_Details')
        
        headers = consistency_df.columns.tolist()
        if 'RawData' in headers:
            raw_idx = headers.index('RawData')
            headers.insert(raw_idx, 'Sparkline')
        
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = self.header_fill
            cell.font = self.header_font
            cell.alignment = self.header_alignment
            cell.border = self.thin_border
        
        for row_idx, (_, row) in enumerate(consistency_df.iterrows(), start=2):
            for col_idx, header in enumerate(headers, start=1):
                if header == 'Sparkline':
                    raw_data = row['RawData']
                    sparkline = generate_sparkline(raw_data)
                    cell = ws.cell(row=row_idx, column=col_idx, value=sparkline)
                    cell.font = Font(name='Consolas', size=9)
                else:
                    value = row[header]
                    if pd.isna(value):
                        value = ''
                    elif isinstance(value, float) and not np.isfinite(value):
                        value = ''
                    cell = ws.cell(row=row_idx, column=col_idx, value=value)
                
                cell.border = self.thin_border
                
                if header == 'Consistency':
                    if value == 'Consistent':
                        cell.fill = self.normal_fill
                    elif value == 'Inconsistent':
                        cell.fill = self.warning_fill
                
                if header == 'Trimmed_Consistency':
                    if value == 'Consistent':
                        cell.fill = self.normal_fill
                    elif value == 'Inconsistent':
                        cell.fill = self.warning_fill
                
                if comparison and header == 'Code' and value in comparison.get('new_inconsistent', []):
                    cell.fill = self.worsened_fill
                    cell.font = Font(bold=True)
        
        ws.freeze_panes = 'A2'
    
    def _create_ttest_sheet(self, wb, ttest_df):
        """Create T-Test details sheet"""
        if ttest_df.empty:
            return
        
        ws = wb.create_sheet(title='6_TTest_Details')
        
        headers = ttest_df.columns.tolist()
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = self.header_fill
            cell.font = self.header_font
            cell.alignment = self.header_alignment
            cell.border = self.thin_border
        
        for row_idx, (_, row) in enumerate(ttest_df.iterrows(), start=2):
            for col_idx, header in enumerate(headers, start=1):
                value = row[header]
                if pd.isna(value):
                    value = ''
                elif isinstance(value, float) and not np.isfinite(value):
                    value = ''
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = self.thin_border
                
                if header == 'TTest_Result':
                    if value == 'Pass':
                        cell.fill = self.normal_fill
                    elif value == 'Fail':
                        cell.fill = self.critical_fill
                        cell.font = Font(color="FFFFFF")
        
        ws.column_dimensions['A'].width = 18
        ws.column_dimensions['B'].width = 50
        ws.freeze_panes = 'A2'
    
    def _create_verification_sheet(self, wb, consistency_df, suspicious_df, ttest_df):
        """Create data verification sheet"""
        ws = wb.create_sheet(title='7_Data_Verification')
        
        verify_info = [
            ['Data Verification Description', '', '', ''],
            ['', '', '', ''],
            ['This sheet shows Python calculated statistics', '', '', ''],
            ['You can manually verify these values in Excel', '', '', ''],
            ['Method: Use COUNTIF function in detail sheets', '', '', ''],
            ['', '', '', ''],
        ]
        
        for row_idx, row_data in enumerate(verify_info, start=1):
            for col_idx, value in enumerate(row_data, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                if row_idx == 1:
                    cell.font = Font(bold=True, size=14)
        
        current_row = 7
        
        # Consistency statistics
        ws.cell(row=current_row, column=1, value='========== Consistency Statistics ==========')
        ws.cell(row=current_row, column=1).font = Font(bold=True)
        current_row += 2
        
        for col_idx, header in enumerate(['Stat Item', 'Python Value', 'Verification Formula'], start=1):
            cell = ws.cell(row=current_row, column=col_idx, value=header)
            cell.fill = self.header_fill
            cell.font = self.header_font
            cell.border = self.thin_border
        current_row += 1
        
        if not consistency_df.empty:
            cons_col_idx = consistency_df.columns.tolist().index('Consistency') + 1
            cons_col_letter = openpyxl.utils.get_column_letter(cons_col_idx)
            
            verify_data = [
                ['Consistent', int((consistency_df['Consistency'] == 'Consistent').sum()), 
                 f"COUNTIF('5_Consistency_Details'!{cons_col_letter}:{cons_col_letter},\"Consistent\")"],
                ['Inconsistent', int((consistency_df['Consistency'] == 'Inconsistent').sum()),
                 f"COUNTIF('5_Consistency_Details'!{cons_col_letter}:{cons_col_letter},\"Inconsistent\")"],
                ['partial NULL', int((consistency_df['Consistency'] == 'partial NULL').sum()),
                 f"COUNTIF('5_Consistency_Details'!{cons_col_letter}:{cons_col_letter},\"partial NULL\")"],
                ['NULL', int((consistency_df['Consistency'] == 'NULL').sum()),
                 f"COUNTIF('5_Consistency_Details'!{cons_col_letter}:{cons_col_letter},\"NULL\")"],
                ['Total Rows', len(consistency_df), "COUNTA('5_Consistency_Details'!A:A)-1"],
            ]
            
            for row_data in verify_data:
                for col_idx, value in enumerate(row_data, start=1):
                    cell = ws.cell(row=current_row, column=col_idx, value=value)
                    cell.border = self.thin_border
                current_row += 1
        
        ws.column_dimensions['A'].width = 20
        ws.column_dimensions['B'].width = 18
        ws.column_dimensions['C'].width = 55
