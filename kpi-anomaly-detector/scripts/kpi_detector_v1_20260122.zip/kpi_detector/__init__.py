# KPI Anomaly Detector Package
# Version: 2.0.0
# Date: 2026-01-21

from .detector import KPIAnomalyDetector
from .config import PATHS, COLORS

__version__ = "2.0.0"
__all__ = ['KPIAnomalyDetector', 'PATHS', 'COLORS']
