#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KPI Anomaly Detector - Main Entry Point
Run this script to analyze KPI data files

Usage:
    python run_detector.py                    # Interactive mode
    python run_detector.py <file.xlsx>        # Analyze specific file
    python run_detector.py --no-html          # Skip HTML report generation
"""

import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from kpi_detector import KPIAnomalyDetector, PATHS


def main():
    """Main entry point"""
    
    print("=" * 60)
    print("KPI Anomaly Detector")
    print("=" * 60)
    print(f"\nDirectory Structure:")
    print(f"   Data Dir: {PATHS['data']}")
    print(f"   Reports Dir: {PATHS['reports']}")
    print(f"   Scripts Dir: {PATHS['scripts']}")
    print(f"   Docs Dir: {PATHS['docs']}")
    
    # Check command line arguments
    generate_html = True
    target_file = None
    
    args = sys.argv[1:]
    for arg in args:
        if arg == '--no-html':
            generate_html = False
        elif arg.endswith('.xlsx'):
            target_file = arg
    
    # If file specified via command line
    if target_file:
        file_path = Path(target_file)
        if not file_path.exists():
            # Try in data directory
            file_path = PATHS['data'] / target_file
        
        if not file_path.exists():
            print(f"\nError: File not found: {target_file}")
            return
        
        print(f"\nAnalyzing: {file_path.name}")
        detector = KPIAnomalyDetector(str(file_path))
        detector.run(generate_html=generate_html)
        
        print("\n" + "=" * 60)
        print(f"Report saved to: {PATHS['reports']}")
        print(f"History file: {PATHS['reports'] / 'kpi_history_records.json'}")
        print("=" * 60)
        return
    
    # Interactive mode
    data_dir = PATHS['data']
    excel_files = list(data_dir.glob("*.xlsx"))
    excel_files = [f for f in excel_files if not f.name.startswith('~$') and 'analysis' not in f.name.lower()]
    
    if len(excel_files) == 0:
        print(f"\nNo Excel data files found in data directory")
        print(f"   Please put raw data files (.xlsx) into: {data_dir}")
        return
    
    print(f"\nAvailable data files ({len(excel_files)}):")
    for i, f in enumerate(excel_files):
        print(f"   {i + 1}. {f.name}")
    
    choice = input("\nSelect file number(s) (e.g., '1' or '1,3,5' or '1-5' or Enter for #1): ").strip()
    
    if choice == '':
        choice = '1'
    
    # Parse selection - support formats: "1", "1,3,5", "1-5", "1,3-5,7"
    selected_indices = []
    try:
        parts = choice.replace(' ', '').split(',')
        for part in parts:
            if '-' in part:
                # Range format: "1-5"
                start, end = part.split('-')
                for i in range(int(start), int(end) + 1):
                    if 1 <= i <= len(excel_files):
                        selected_indices.append(i)
            else:
                # Single number
                i = int(part)
                if 1 <= i <= len(excel_files):
                    selected_indices.append(i)
        
        if not selected_indices:
            print("Invalid selection: no valid file numbers")
            return
            
    except ValueError:
        print("Invalid selection format")
        return
    
    # Remove duplicates while preserving order
    seen = set()
    selected_indices = [x for x in selected_indices if not (x in seen or seen.add(x))]
    
    print(f"\nWill process {len(selected_indices)} file(s) in order: {selected_indices}")
    
    # Run analysis for each selected file
    for idx, file_num in enumerate(selected_indices, 1):
        current_file = str(excel_files[file_num - 1])
        print(f"\n{'='*60}")
        print(f"[{idx}/{len(selected_indices)}] Analyzing: {excel_files[file_num - 1].name}")
        print(f"{'='*60}")
        
        detector = KPIAnomalyDetector(current_file)
        detector.run(generate_html=generate_html)
    
    print("\n" + "=" * 60)
    print(f"Completed {len(selected_indices)} file(s)")
    print(f"Reports saved to: {PATHS['reports']}")
    print(f"History file: {PATHS['reports'] / 'kpi_history_records.json'}")
    print("=" * 60)


if __name__ == "__main__":
    main()
