# -*- coding: utf-8 -*-
"""
HTML Report Generator Module
Generates interactive HTML reports with trend visualization and filter shortcuts
Uses echarts for professional visualization with dual chart view:
- Data Detail Chart: Shows all historical raw data together
- SPC Control Chart: Shows Shewhart X-bar chart with control limits
"""

import json
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np


class HTMLReportGenerator:
    """Generate interactive HTML analysis reports with echarts"""
    
    # Color palette for historical series
    COLORS = [
        '#E6E6E6', '#D9D9D9', '#CCCCCC', '#BFBFBF', '#B3B3B3',
        '#A6A6A6', '#999999', '#8C8C8C', '#808080', '#737373',
        '#666666', '#595959', '#4D4D4D', '#404040', '#333333',
        '#1976D2'  # Last color is for current file (blue)
    ]
    
    def __init__(self, output_dir: Path):
        """Initialize HTML report generator
        
        Args:
            output_dir: Directory for output files
        """
        self.output_dir = output_dir
    
    def generate(self, filename: str, analysis_results: Dict[str, Any],
                 comparison: Optional[Dict] = None,
                 history_records: list = None) -> Path:
        """Generate HTML report
        
        Args:
            filename: Base filename (without extension)
            analysis_results: Analysis results dictionary
            comparison: Comparison with history
            history_records: List of historical records
            
        Returns:
            Path to generated HTML file
        """
        output_file = self.output_dir / f"{filename}_trend_viewer.html"
        
        consistency_df = analysis_results.get('consistency', pd.DataFrame())
        suspicious_df = analysis_results.get('suspicious', pd.DataFrame())
        all_codes_df = analysis_results.get('all_codes', pd.DataFrame())
        
        # Prepare data for JavaScript - includes both SPC and raw data
        kpi_data = self._prepare_kpi_data(all_codes_df, history_records or [])
        
        html_content = self._generate_html(
            filename=filename,
            consistency_df=consistency_df,
            suspicious_df=suspicious_df,
            all_codes_df=all_codes_df,
            comparison=comparison,
            kpi_data=kpi_data
        )
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"HTML report saved to: {output_file}")
        return output_file
    
    def _prepare_kpi_data(self, all_codes_df: pd.DataFrame, 
                          history_records: list) -> Dict:
        """Prepare comprehensive KPI data including history for trend charts"""
        kpi_data = {}
        
        if all_codes_df.empty:
            return kpi_data
        
        for _, row in all_codes_df.iterrows():
            code = row.get('Code', '')
            if not code:
                continue
            
            # Get shewhart chart data
            shewhart_chart = row.get('_shewhart_chart', {})
            if isinstance(shewhart_chart, dict):
                shewhart_data = shewhart_chart
            else:
                shewhart_data = {}
            
            # Calculate historical stats
            hist_mean = row.get('Hist_Mean')
            hist_std = row.get('Hist_Std')
            
            # Prepare historical data series
            history_series = self._extract_history_series(code, history_records, row)
            
            # Calculate CV consistency stats across all batches
            cv_stats = self._calculate_cv_stats(history_series)
            
            # Check for degenerate (zero-variance) case
            is_degenerate = row.get('Is_Degenerate', False)
            degenerate_type = row.get('Degenerate_Type', '')
            
            kpi_data[code] = {
                'kpi_name': row.get('KPI Name', ''),
                'type': row.get('Type', 'Other'),
                'severity': row.get('Severity', 'Unknown'),
                'reasons': row.get('Reasons', ''),
                'consistency': row.get('Consistency', ''),
                'cv': self._safe_float(row.get('CV(%)')),
                'z_score': self._safe_float(row.get('Z_Score')),
                'sigma_level': self._safe_float(row.get('Sigma_Level')),
                'trend': row.get('Trend', ''),
                'ttest_result': row.get('TTest_Result', 'N/A'),
                'current_mean': self._safe_float(row.get('Current_Mean')),
                'hist_mean': self._safe_float(hist_mean),
                'hist_std': self._safe_float(hist_std),
                'anomaly_count': int(row.get('Anomaly_Count', 0)) if pd.notna(row.get('Anomaly_Count')) else 0,
                'total_points': int(row.get('Total_Points', 0)) if pd.notna(row.get('Total_Points')) else 0,
                'anomaly_indices': row.get('Anomaly_Indices', []),
                'spc_zone': row.get('SPC_Zone', ''),
                'spc_violations': row.get('SPC_Violations', ''),
                'shewhart_chart': shewhart_data,
                'history': history_series,
                'cv_stats': cv_stats,
                'is_degenerate': is_degenerate,
                'degenerate_type': degenerate_type,
                'hist_stats': {
                    'mean': self._safe_float(hist_mean),
                    'upper_2sigma': self._safe_float(hist_mean + 2 * hist_std) if hist_mean and hist_std else None,
                    'lower_2sigma': self._safe_float(hist_mean - 2 * hist_std) if hist_mean and hist_std else None,
                    'upper_3sigma': self._safe_float(hist_mean + 3 * hist_std) if hist_mean and hist_std else None,
                    'lower_3sigma': self._safe_float(hist_mean - 3 * hist_std) if hist_mean and hist_std else None,
                }
            }
        
        return kpi_data
    
    def _calculate_cv_stats(self, history_series: List[Dict]) -> Dict:
        """Calculate CV consistency statistics across all batches"""
        total = len(history_series)
        # Fix: Check for both 'OK' and 'Consistent' as consistent states
        consistent_count = sum(1 for h in history_series 
                               if h.get('consistency') in ('OK', 'Consistent'))
        # Fix: Check for both 'NG' and 'Inconsistent' as inconsistent states
        inconsistent_count = sum(1 for h in history_series 
                                 if h.get('consistency') in ('NG', 'Inconsistent'))
        partial_null_count = sum(1 for h in history_series 
                                 if 'partial' in str(h.get('consistency', '')).lower() 
                                 or 'null' in str(h.get('consistency', '')).lower())
        
        return {
            'total': total,
            'consistent': consistent_count,
            'inconsistent': inconsistent_count,
            'partial_null': partial_null_count,
            'consistent_ratio': f"{consistent_count}/{total}" if total > 0 else "0/0"
        }
    
    def _parse_raw_data_string(self, raw_data) -> List[float]:
        """Parse raw data string (comma-separated values) to list of floats"""
        if raw_data is None or (isinstance(raw_data, float) and np.isnan(raw_data)):
            return []
        if isinstance(raw_data, (list, np.ndarray)):
            return [float(v) for v in raw_data if v is not None and not np.isnan(v)]
        if isinstance(raw_data, str) and raw_data.strip():
            try:
                return [float(x.strip()) for x in raw_data.split(',') if x.strip()]
            except ValueError:
                return []
        return []
    
    def _extract_history_series(self, code: str, history_records: list, 
                                 current_row: pd.Series) -> List[Dict]:
        """Extract historical raw data series for a code"""
        history_series = []
        
        # Add historical records
        # History record structure: record['kpi_data'][code]['raw_data']
        for i, record in enumerate(history_records):
            kpi_data = record.get('kpi_data', {})
            if code in kpi_data and 'raw_data' in kpi_data[code]:
                raw_values = kpi_data[code]['raw_data']
                # Parse values - could be list or comma-separated string
                values = self._parse_raw_data_string(raw_values)
                if len(values) > 0:
                    # Calculate CV for this batch
                    arr = np.array(values)
                    cv = (np.std(arr) / np.mean(arr) * 100) if len(arr) > 0 and np.mean(arr) != 0 else None
                    hist_consistency = kpi_data[code].get('consistency', '')
                    consistency = 'OK' if cv and cv < 10 else 'NG' if cv else '-'
                    
                    history_series.append({
                        'label': record.get('filename', f'History_{i+1}'),
                        'timestamp': record.get('timestamp', ''),
                        'values': values,
                        'raw_values': values,  # Keep raw values for table display
                        'cv': self._safe_float(cv),
                        'consistency': hist_consistency if hist_consistency else consistency,
                        'is_current': False
                    })
                else:
                    # Code exists but raw_data is empty
                    history_series.append({
                        'label': record.get('filename', f'History_{i+1}'),
                        'timestamp': record.get('timestamp', ''),
                        'values': [],
                        'raw_values': [],
                        'cv': None,
                        'consistency': kpi_data[code].get('consistency', 'NULL'),
                        'is_current': False
                    })
            else:
                # Code not found in this history record - add NULL entry
                history_series.append({
                    'label': record.get('filename', f'History_{i+1}'),
                    'timestamp': record.get('timestamp', ''),
                    'values': [],
                    'raw_values': [],
                    'cv': None,
                    'consistency': 'NULL',
                    'is_current': False
                })
        
        # Add current file data - stored as 'Current_Data' string in detector.py
        current_raw = current_row.get('Current_Data', '')
        current_values = self._parse_raw_data_string(current_raw)
        current_consistency = current_row.get('Consistency', '-')
        
        if len(current_values) > 0:
            arr = np.array(current_values)
            cv = (np.std(arr) / np.mean(arr) * 100) if len(arr) > 0 and np.mean(arr) != 0 else None
            
            history_series.append({
                'label': 'Current',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'values': current_values,
                'raw_values': current_values,
                'cv': self._safe_float(cv),
                'consistency': current_consistency,
                'is_current': True
            })
        else:
            # Current has no data - NULL
            history_series.append({
                'label': 'Current',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'values': [],
                'raw_values': [],
                'cv': None,
                'consistency': 'NULL' if not current_consistency or current_consistency == '-' else current_consistency,
                'is_current': True
            })
        
        return history_series
    
    def _safe_float(self, value) -> Optional[float]:
        """Convert value to float safely, returning None for invalid values"""
        if value is None:
            return None
        if isinstance(value, (int, float)):
            if np.isnan(value) or np.isinf(value):
                return None
            return float(value)
        try:
            f = float(value)
            if np.isnan(f) or np.isinf(f):
                return None
            return f
        except (ValueError, TypeError):
            return None

    def _generate_html(self, filename: str, consistency_df: pd.DataFrame,
                       suspicious_df: pd.DataFrame, all_codes_df: pd.DataFrame,
                       comparison: Optional[Dict], kpi_data: Dict) -> str:
        """Generate HTML content with echarts visualization"""
        
        # Statistics
        stats = self._calculate_statistics(consistency_df, suspicious_df, all_codes_df)
        
        # Generate KPI list HTML grouped by severity
        kpi_list_html = self._generate_kpi_list_html(all_codes_df)
        
        # Convert data to JSON for JavaScript
        kpi_data_json = json.dumps(kpi_data, ensure_ascii=False, default=str)
        colors_json = json.dumps(self.COLORS)
        
        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KPI Anomaly Trend Viewer - {filename}</title>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f0f2f5;
        }}
        .container {{
            display: flex;
            height: 100vh;
        }}
        
        /* Left Panel */
        .left-panel {{
            width: 380px;
            background: white;
            border-right: 1px solid #e0e0e0;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }}
        .header {{
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }}
        .header h1 {{
            font-size: 18px;
            margin-bottom: 15px;
        }}
        .search-box {{
            width: 100%;
            padding: 10px 15px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            background: rgba(255,255,255,0.9);
        }}
        .search-box:focus {{ outline: none; background: white; }}
        
        /* Summary Panel */
        .summary-panel {{
            padding: 15px;
            background: #f8f9fa;
            border-bottom: 1px solid #e0e0e0;
        }}
        .summary-title {{
            font-size: 13px;
            color: #666;
            margin-bottom: 10px;
        }}
        .summary-stats {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }}
        .summary-item {{
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .summary-item:hover {{ transform: translateY(-1px); }}
        .summary-item.active {{ box-shadow: 0 2px 8px rgba(0,0,0,0.2); }}
        .summary-item.all {{ background: #e3f2fd; color: #1976d2; }}
        .summary-item.regression {{ background: #ffebee; color: #c62828; }}
        .summary-item.suspicious {{ background: #fff3e0; color: #e65100; }}
        .summary-item.normal {{ background: #e8f5e9; color: #2e7d32; }}
        .summary-item.no-history {{ background: #f5f5f5; color: #666; }}
        
        /* Type Filter Buttons */
        .type-filter {{
            padding: 10px 15px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            gap: 8px;
        }}
        .type-btn {{
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            font-size: 11px;
            cursor: pointer;
            transition: all 0.2s;
        }}
        .type-btn.kpi {{ background: #e8f5e9; color: #2e7d32; }}
        .type-btn.counter {{ background: #fff3e0; color: #e65100; }}
        .type-btn.all {{ background: #e3f2fd; color: #1976d2; }}
        .type-btn.active {{ box-shadow: 0 2px 6px rgba(0,0,0,0.2); font-weight: bold; }}
        .shortcut-hint {{ font-size: 9px; opacity: 0.7; margin-left: 3px; }}
        
        /* KPI List */
        .kpi-list {{
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }}
        .severity-group {{
            margin-bottom: 15px;
        }}
        .severity-header {{
            padding: 8px 12px;
            color: white;
            font-size: 12px;
            font-weight: 600;
            border-radius: 6px;
            margin-bottom: 8px;
        }}
        .severity-items {{
            display: flex;
            flex-direction: column;
            gap: 4px;
        }}
        .kpi-item {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 12px;
            background: #f8f9fa;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 12px;
        }}
        .kpi-item:hover {{ background: #e3f2fd; }}
        .kpi-item.active {{ background: #1976d2; color: white; }}
        .kpi-item .code {{ font-weight: 500; }}
        .kpi-item .type {{ color: #888; font-size: 11px; }}
        .kpi-item.active .type {{ color: rgba(255,255,255,0.8); }}
        
        /* Right Panel */
        .right-panel {{
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #f5f5f5;
            overflow: hidden;
        }}
        .chart-header {{
            padding: 20px;
            background: white;
            border-bottom: 1px solid #e0e0e0;
        }}
        .title-row {{
            display: flex;
            align-items: baseline;
            gap: 15px;
            margin-bottom: 10px;
        }}
        .title-row h2 {{
            font-size: 20px;
            color: #333;
        }}
        .kpi-name {{
            color: #e91e63;
            font-size: 18px;
            font-weight: bold;
        }}
        .info-row {{
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 15px;
        }}
        .info-item {{
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
        }}
        .stats-row {{
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }}
        .stat-box {{
            background: #f8f9fa;
            padding: 12px 16px;
            border-radius: 8px;
            min-width: 100px;
        }}
        .stat-box.warning {{ background: #fff3e0; }}
        .stat-box.danger {{ background: #ffebee; }}
        .stat-label {{
            font-size: 11px;
            color: #888;
            margin-bottom: 4px;
        }}
        .stat-value {{
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }}
        .stat-value.good {{ color: #2e7d32; }}
        .stat-value.warning {{ color: #e65100; }}
        .stat-value.danger {{ color: #c62828; }}
        
        /* Judgment Row - Combined Judgment Area and SPC Violations */
        .judgment-row {{
            display: flex;
            gap: 10px;
            margin-top: 10px;
            flex-wrap: wrap;
        }}
        
        /* SPC Violations */
        .spc-violations {{
            flex: 1;
            min-width: 200px;
            padding: 10px 14px;
            background: #ffebee;
            border-radius: 6px;
            font-size: 12px;
            color: #c62828;
            display: flex;
            align-items: center;
        }}
        
        /* Judgment Area */
        .judgment-area {{
            flex: 2;
            min-width: 300px;
            padding: 10px 16px;
            border-radius: 8px;
            font-size: 13px;
            display: flex;
            align-items: center;
        }}
        .judgment-normal {{ background: #e8f5e9; color: #2e7d32; }}
        .judgment-warning {{ background: #fff3e0; color: #e65100; }}
        .judgment-abnormal {{ background: #ffebee; color: #c62828; }}
        
        /* Chart Tabs */
        .chart-tabs {{
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }}
        .tab-btn {{
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s;
            background: #e0e0e0;
            color: #666;
        }}
        .tab-btn:hover {{ background: #d0d0d0; }}
        .tab-btn.active {{
            background: #1976d2;
            color: white;
            box-shadow: 0 2px 8px rgba(25, 118, 210, 0.3);
        }}
        
        /* Chart Container */
        .chart-container {{
            flex: 1;
            padding: 20px;
            position: relative;
            min-height: 400px;
        }}
        #chart, #spcChart {{
            width: 100%;
            height: 100%;
            min-height: 400px;
        }}
        .placeholder {{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: #999;
            font-size: 16px;
        }}
        
        /* Legend Area */
        .legend-area {{
            padding: 15px 20px;
            background: white;
            border-top: 1px solid #e0e0e0;
            max-height: 300px;
            overflow-y: auto;
            overflow-x: auto;
        }}
        .legend-title {{
            font-size: 12px;
            color: #666;
            margin-bottom: 10px;
        }}
        .legend-items {{
            display: flex;
            flex-direction: column;
            gap: 6px;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            font-size: 11px;
            padding: 6px 10px;
            background: #f8f9fa;
            border-radius: 4px;
        }}
        .legend-item.current {{
            background: #e3f2fd;
            font-weight: bold;
        }}
        .legend-color {{
            width: 24px;
            height: 3px;
            margin-right: 10px;
            border-radius: 2px;
            flex-shrink: 0;
        }}
        
        /* Data Table Styles */
        .data-table-container {{
            margin-top: 10px;
            overflow-x: auto;
        }}
        .data-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
        }}
        .data-table th, .data-table td {{
            padding: 6px 8px;
            border: 1px solid #e0e0e0;
            text-align: center;
            white-space: nowrap;
        }}
        .data-table th {{
            background: #f5f5f5;
            font-weight: 600;
            position: sticky;
            top: 0;
        }}
        .data-table th.filename {{
            text-align: left;
            min-width: 150px;
            max-width: 250px;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .data-table td.filename {{
            text-align: left;
            max-width: 250px;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        .data-table tr.current {{
            background: #e3f2fd;
            font-weight: bold;
        }}
        .data-table tr:hover {{
            background: #f0f7ff;
        }}
        .data-table .cv-ok {{ color: #2e7d32; }}
        .data-table .cv-ng {{ color: #c62828; }}
        .data-table .cv-null {{ color: #9e9e9e; font-style: italic; }}
        .data-table .anomaly-cell {{ 
            background: #ffebee !important; 
            color: #c62828; 
            font-weight: bold;
            border: 2px solid #f44336 !important;
        }}
        .data-table th.anomaly-header {{
            background: #ffcdd2 !important;
            color: #c62828;
        }}
        
        /* All Anomaly Badge */
        .all-anomaly-badge {{
            background: #f44336;
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 9px;
            margin-left: 4px;
            animation: pulse 1.5s infinite;
        }}
        @keyframes pulse {{
            0% {{ opacity: 1; }}
            50% {{ opacity: 0.6; }}
            100% {{ opacity: 1; }}
        }}
        
        /* Anomaly Filter Dropdown */
        .anomaly-filter-container {{
            position: relative;
            display: inline-block;
        }}
        .anomaly-dropdown {{
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 100;
            min-width: 160px;
            padding: 8px 0;
            margin-top: 4px;
        }}
        .anomaly-dropdown.show {{ display: block; }}
        .anomaly-dropdown-item {{
            padding: 8px 16px;
            cursor: pointer;
            font-size: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .anomaly-dropdown-item:hover {{ background: #f0f7ff; }}
        .anomaly-dropdown-item.active {{ background: #e3f2fd; color: #1976d2; font-weight: bold; }}
        .anomaly-dropdown-item .count {{ color: #666; font-size: 10px; }}
        
        /* Advanced Filter Panel */
        .advanced-filter {{
            padding: 10px 15px;
            border-bottom: 1px solid #e0e0e0;
            background: #fafafa;
        }}
        .filter-title {{
            font-size: 11px;
            color: #666;
            margin-bottom: 8px;
        }}
        .filter-options {{
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }}
        .filter-chip {{
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 10px;
            cursor: pointer;
            transition: all 0.2s;
            border: 1px solid #ddd;
            background: white;
        }}
        .filter-chip:hover {{
            background: #f0f0f0;
        }}
        .filter-chip.active {{
            background: #1976d2;
            color: white;
            border-color: #1976d2;
        }}
        .filter-chip.exclude {{
            background: #ffebee;
            color: #c62828;
            border-color: #ffcdd2;
        }}
        .filter-chip.exclude.active {{
            background: #c62828;
            color: white;
        }}
        
        /* History Management Modal */
        .modal-overlay {{
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }}
        .modal-overlay.active {{ display: flex; }}
        .modal {{
            background: white;
            border-radius: 12px;
            max-width: 700px;
            width: 90%;
            max-height: 80vh;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }}
        .modal-header {{
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .modal-header h3 {{ font-size: 18px; }}
        .modal-close {{
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            opacity: 0.8;
        }}
        .modal-close:hover {{ opacity: 1; }}
        .modal-body {{
            padding: 20px;
            max-height: 60vh;
            overflow-y: auto;
        }}
        .history-list {{
            display: flex;
            flex-direction: column;
            gap: 8px;
        }}
        .history-item {{
            display: flex;
            align-items: center;
            padding: 12px;
            background: #f8f9fa;
            border-radius: 8px;
            gap: 12px;
        }}
        .history-item:hover {{ background: #e3f2fd; }}
        .history-item.current {{ background: #e8f5e9; border: 2px solid #4CAF50; }}
        .history-item.marked-invalid {{ background: #ffebee; opacity: 0.7; }}
        .history-checkbox {{
            width: 18px;
            height: 18px;
            cursor: pointer;
        }}
        .history-info {{
            flex: 1;
        }}
        .history-filename {{
            font-weight: 500;
            font-size: 13px;
            color: #333;
        }}
        .history-time {{
            font-size: 11px;
            color: #666;
        }}
        .history-stats {{
            font-size: 11px;
            color: #888;
        }}
        .history-badge {{
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 500;
        }}
        .history-badge.current {{ background: #4CAF50; color: white; }}
        .history-badge.invalid {{ background: #f44336; color: white; }}
        .modal-footer {{
            padding: 15px 20px;
            background: #f5f5f5;
            border-top: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .modal-btn {{
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
        }}
        .modal-btn.primary {{ background: #1976d2; color: white; }}
        .modal-btn.primary:hover {{ background: #1565c0; }}
        .modal-btn.danger {{ background: #f44336; color: white; }}
        .modal-btn.danger:hover {{ background: #d32f2f; }}
        .modal-btn.secondary {{ background: #e0e0e0; color: #333; }}
        .modal-btn.secondary:hover {{ background: #d0d0d0; }}
        .selected-count {{ font-size: 12px; color: #666; }}
        
        /* Manage History Button */
        .manage-history-btn {{
            margin-top: 10px;
            padding: 8px 12px;
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 6px;
            color: white;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            width: 100%;
        }}
        .manage-history-btn:hover {{ background: rgba(255,255,255,0.3); }}
        
        /* Command output area */
        .command-output {{
            margin-top: 15px;
            padding: 12px;
            background: #263238;
            border-radius: 6px;
            color: #4CAF50;
            font-family: monospace;
            font-size: 11px;
            white-space: pre-wrap;
            display: none;
        }}
        .command-output.show {{ display: block; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <div class="header">
                <h1>KPI Anomaly Trend Viewer</h1>
                <input type="text" class="search-box" id="searchBox" 
                       placeholder="Search Code or KPI Name... (Press /)" oninput="filterList()">
                <button class="manage-history-btn" onclick="openHistoryModal()">📋 Manage History Records (M)</button>
            </div>
            <div class="summary-panel">
                <div class="summary-title">Severity Statistics (based on historical sigma)</div>
                <div class="summary-stats">
                    <div class="summary-item all active" onclick="filterBySeverity('all')">
                        All <b id="statTotal">{stats['total']}</b>
                    </div>
                    <div class="summary-item regression" onclick="filterBySeverity('Regression')">
                        Regression <b id="statRegression">{stats['regression']}</b>
                    </div>
                    <div class="summary-item suspicious" onclick="filterBySeverity('Suspicious')">
                        Suspicious <b id="statSuspicious">{stats['suspicious']}</b>
                    </div>
                    <div class="summary-item normal" onclick="filterBySeverity('Normal')">
                        Normal <b id="statNormal">{stats['normal']}</b>
                    </div>
                    <div class="summary-item no-history" onclick="filterBySeverity('NoHistory')">
                        No History <b id="statNoHistory">{stats['nohistory']}</b>
                    </div>
                </div>
            </div>
            <div class="type-filter">
                <button class="type-btn all active" onclick="filterByType('all')">All</button>
                <button class="type-btn kpi" onclick="filterByType('KPI')">KPI <span class="shortcut-hint">(K)</span></button>
                <button class="type-btn counter" onclick="filterByType('Counter')">Counter <span class="shortcut-hint">(C)</span></button>
            </div>
            <div class="advanced-filter">
                <div class="filter-title">Advanced Filters <span class="shortcut-hint">(Press H for help)</span></div>
                <div class="filter-options">
                    <div class="anomaly-filter-container">
                        <span class="filter-chip" onclick="toggleAnomalyDropdown(event)" data-filter="hasAnomaly" id="anomalyFilterChip">Anomaly ≥1 <span class="shortcut-hint">(N)</span></span>
                        <div class="anomaly-dropdown" id="anomalyDropdown">
                            <div class="anomaly-dropdown-item" data-threshold="0" onclick="setAnomalyThreshold(0)">Any (disabled) <span class="count"></span></div>
                            <div class="anomaly-dropdown-item active" data-threshold="1" onclick="setAnomalyThreshold(1)">Anomaly ≥1 <span class="count" id="anomalyCount1"></span></div>
                            <div class="anomaly-dropdown-item" data-threshold="-1" onclick="setAnomalyThreshold(-1)">All Anomaly ⚠️ <span class="count" id="anomalyCountAll"></span></div>
                        </div>
                    </div>
                    <span class="filter-chip exclude" onclick="toggleAdvancedFilter('excludeNull')" data-filter="excludeNull">Exclude NULL <span class="shortcut-hint">(X)</span></span>
                    <span class="filter-chip exclude" onclick="toggleAdvancedFilter('excludePartialNull')" data-filter="excludePartialNull">Exclude Partial NULL <span class="shortcut-hint">(P)</span></span>
                    <span class="filter-chip" onclick="toggleAdvancedFilter('onlyInconsistent')" data-filter="onlyInconsistent">Only Inconsistent <span class="shortcut-hint">(I)</span></span>
                </div>
            </div>
            <div class="kpi-list" id="kpiList">
                {kpi_list_html}
            </div>
        </div>
        
        <div class="right-panel">
            <div class="chart-header" id="chartHeader" style="display: none;">
                <div class="title-row">
                    <h2 id="chartTitle">-</h2>
                    <span class="kpi-name" id="chartKpiName">-</span>
                </div>
                <div class="info-row">
                    <span class="info-item" id="chartSeverity">-</span>
                    <span class="info-item" id="chartConsistency">-</span>
                    <span class="info-item" id="chartCVStats" style="background: #f3e5f5; color: #7b1fa2;">-</span>
                    <span class="info-item" id="chartTTest">-</span>
                    <span class="info-item" id="chartReasons" style="background: #fff8e1; color: #f57c00; max-width: 400px; overflow: hidden; text-overflow: ellipsis;">-</span>
                </div>
                <div class="stats-row" id="statsRow">
                    <div class="stat-box">
                        <span class="stat-label">Current Mean</span>
                        <span class="stat-value" id="currentMean">-</span>
                    </div>
                    <div class="stat-box history">
                        <span class="stat-label">History Mean</span>
                        <span class="stat-value" id="historyMean">-</span>
                    </div>
                    <div class="stat-box zscore" id="zscoreBox">
                        <span class="stat-label">Sigma Level</span>
                        <span class="stat-value" id="sigmaLevel">-</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-label">Anomaly Count</span>
                        <span class="stat-value" id="anomalyCount">-</span>
                    </div>
                    <div class="stat-box spc" id="spcBox">
                        <span class="stat-label">SPC Zone</span>
                        <span class="stat-value" id="spcZone">-</span>
                    </div>
                </div>
                <div class="judgment-row" id="judgmentRow">
                    <div class="judgment-area" id="judgmentArea" style="display: none;">
                        <span id="judgmentText">-</span>
                    </div>
                    <div class="spc-violations" id="spcViolations" style="display: none;">
                        <b>Rule Violations:</b> <span id="spcViolationsText"></span>
                    </div>
                </div>
                <div class="chart-tabs" id="chartTabs" style="display: none;">
                    <button class="tab-btn active" onclick="switchChartType('detail')">Data Detail <span class="shortcut-hint">(1)</span></button>
                    <button class="tab-btn" onclick="switchChartType('spc')">SPC Control <span class="shortcut-hint">(2)</span></button>
                    <button class="tab-btn" onclick="switchChartType('both')">Both Charts <span class="shortcut-hint">(3)</span></button>
                </div>
            </div>
            <div class="chart-container">
                <div id="chart"></div>
                <div id="spcChart" style="display: none;"></div>
                <div class="placeholder" id="placeholder">
                    Click a Code on the left to view trend chart
                </div>
            </div>
            <div class="legend-area" id="legendArea" style="display: none;">
                <div class="legend-title">Data Sources (oldest to newest):</div>
                <div class="legend-items" id="legendItems"></div>
            </div>
        </div>
    </div>
    
    <!-- History Management Modal -->
    <div class="modal-overlay" id="historyModal">
        <div class="modal">
            <div class="modal-header">
                <h3>📋 Manage History Records</h3>
                <button class="modal-close" onclick="closeHistoryModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 15px; color: #666; font-size: 13px;">
                    Select records to mark as invalid. Invalid records will be excluded from future analysis.<br>
                    <b>Note:</b> This generates a command to run in terminal. Copy and execute it to apply changes.
                </p>
                <div class="history-list" id="historyList">
                    <!-- Populated by JavaScript -->
                </div>
                <div class="command-output" id="commandOutput"></div>
            </div>
            <div class="modal-footer">
                <span class="selected-count" id="selectedCount">0 selected</span>
                <div>
                    <button class="modal-btn secondary" onclick="selectAllHistory()">Select All</button>
                    <button class="modal-btn secondary" onclick="deselectAllHistory()">Deselect All</button>
                    <button class="modal-btn danger" onclick="generateDeleteCommand()">🗑️ Generate Delete Command</button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // KPI data from Python
        const kpiData = {kpi_data_json};
        const colors = {colors_json};
        
        // Chart instances
        let chart = null;
        let spcChart = null;
        let currentCode = null;
        let currentChartType = 'detail';
        let currentSeverityFilter = 'all';
        let currentTypeFilter = 'all';
        
        // Advanced filters
        let advancedFilters = {{
            hasAnomaly: false,
            anomalyThreshold: 1,  // 1 = at least 1, -1 = all anomaly (all points)
            excludeNull: false,
            excludePartialNull: false,
            onlyInconsistent: false
        }};
        
        // KPI pattern: NR_XXXXx or SCOUT_NR_XXXXx
        const KPI_PATTERN = /((?:SCOUT_)?NR_\\d{{2,4}})([a-zA-Z])/i;
        // Counter pattern: MxxxxxCxxxxx
        const COUNTER_PATTERN = /^M\\d{{5}}C\\d{{1,5}}$/i;
        
        function isKPICode(code) {{
            return KPI_PATTERN.test(code);
        }}
        
        function isCounterCode(code) {{
            return COUNTER_PATTERN.test(code);
        }}
        
        // Initialize charts
        function initChart() {{
            const chartDom = document.getElementById('chart');
            const spcChartDom = document.getElementById('spcChart');
            chart = echarts.init(chartDom);
            spcChart = echarts.init(spcChartDom);
            
            window.addEventListener('resize', function() {{
                chart && chart.resize();
                spcChart && spcChart.resize();
            }});
        }}
        
        // Switch between chart types
        function switchChartType(type) {{
            currentChartType = type;
            
            // Update tab buttons
            document.querySelectorAll('.tab-btn').forEach((btn, idx) => {{
                btn.classList.remove('active');
                if ((type === 'detail' && idx === 0) || 
                    (type === 'spc' && idx === 1) || 
                    (type === 'both' && idx === 2)) {{
                    btn.classList.add('active');
                }}
            }});
            
            const chartEl = document.getElementById('chart');
            const spcChartEl = document.getElementById('spcChart');
            const chartContainer = document.querySelector('.chart-container');
            
            if (type === 'detail') {{
                chartEl.style.display = 'block';
                spcChartEl.style.display = 'none';
                chartEl.style.width = '100%';
                chartEl.style.height = '100%';
                chartContainer.style.flexDirection = 'column';
                // Redraw chart and resize
                if (currentCode) {{
                    const data = kpiData[currentCode];
                    if (data) {{
                        drawDetailChart(currentCode, data);
                    }}
                }}
                setTimeout(() => {{ chart && chart.resize(); }}, 50);
            }} else if (type === 'spc') {{
                chartEl.style.display = 'none';
                spcChartEl.style.display = 'block';
                spcChartEl.style.width = '100%';
                spcChartEl.style.height = '100%';
                chartContainer.style.flexDirection = 'column';
                if (currentCode) {{
                    showSPCChart(currentCode);
                }}
                setTimeout(() => {{ spcChart && spcChart.resize(); }}, 50);
            }} else if (type === 'both') {{
                chartEl.style.display = 'block';
                spcChartEl.style.display = 'block';
                chartEl.style.width = '50%';
                chartEl.style.height = '100%';
                spcChartEl.style.width = '50%';
                spcChartEl.style.height = '100%';
                chartContainer.style.flexDirection = 'row';
                if (currentCode) {{
                    // Redraw both charts
                    const data = kpiData[currentCode];
                    if (data) {{
                        drawDetailChart(currentCode, data);
                        showSPCChart(currentCode);
                    }}
                }}
                // Resize charts after layout change
                setTimeout(() => {{
                    chart && chart.resize();
                    spcChart && spcChart.resize();
                }}, 100);
            }}
        }}
        
        // Show Data Detail Chart
        function showChart(code) {{
            const data = kpiData[code];
            if (!data) {{
                alert('No data available for this code');
                return;
            }}
            
            currentCode = code;
            
            // Update selection
            document.querySelectorAll('.kpi-item').forEach(item => {{
                item.classList.remove('active');
                if (item.dataset.code === code) {{
                    item.classList.add('active');
                }}
            }});
            
            // Show chart area
            document.getElementById('placeholder').style.display = 'none';
            document.getElementById('chartHeader').style.display = 'block';
            document.getElementById('legendArea').style.display = 'block';
            document.getElementById('chartTabs').style.display = 'flex';
            
            // Update header info
            document.getElementById('chartTitle').textContent = code;
            const kpiNameEl = document.getElementById('chartKpiName');
            kpiNameEl.textContent = data.kpi_name || '-';
            kpiNameEl.style.color = '#e91e63';
            kpiNameEl.style.fontSize = '18px';
            kpiNameEl.style.fontWeight = 'bold';
            
            // Update severity display
            const sevEl = document.getElementById('chartSeverity');
            const severity = data.severity || '-';
            sevEl.textContent = 'Severity: ' + severity;
            sevEl.className = 'info-item';
            if (severity === 'Regression') {{
                sevEl.style.background = '#ffebee';
                sevEl.style.color = '#c62828';
            }} else if (severity === 'Suspicious') {{
                sevEl.style.background = '#fff3e0';
                sevEl.style.color = '#e65100';
            }} else if (severity === 'Normal') {{
                sevEl.style.background = '#e8f5e9';
                sevEl.style.color = '#2e7d32';
            }} else {{
                sevEl.style.background = '#f5f5f5';
                sevEl.style.color = '#666';
            }}
            
            // Update CV display with stats
            const cvEl = document.getElementById('chartConsistency');
            cvEl.textContent = 'Current CV: ' + (data.consistency || '-');
            
            // Update CV Stats (consistent ratio across all batches)
            const cvStatsEl = document.getElementById('chartCVStats');
            const cvStats = data.cv_stats || {{}};
            cvStatsEl.textContent = `CV Consistency: ${{cvStats.consistent_ratio || '0/0'}} OK`;
            
            document.getElementById('chartTTest').textContent = 'T-Test: ' + (data.ttest_result || 'N/A');
            
            // Update reasons display
            const reasonsEl = document.getElementById('chartReasons');
            const reasons = data.reasons || '';
            reasonsEl.textContent = 'Reasons: ' + (reasons || 'Normal');
            reasonsEl.title = reasons || 'Normal';  // Show full text on hover
            
            // Update stats
            document.getElementById('currentMean').textContent = 
                data.current_mean !== null ? data.current_mean.toFixed(2) : '-';
            document.getElementById('historyMean').textContent = 
                data.hist_mean !== null ? data.hist_mean.toFixed(2) : '-';
            
            // Sigma level
            const sigmaEl = document.getElementById('sigmaLevel');
            const zscoreBox = document.getElementById('zscoreBox');
            if (data.sigma_level !== null) {{
                sigmaEl.textContent = data.sigma_level.toFixed(2) + 'σ';
                sigmaEl.className = 'stat-value';
                zscoreBox.className = 'stat-box zscore';
                if (data.sigma_level <= 2) {{
                    sigmaEl.classList.add('good');
                }} else if (data.sigma_level <= 3) {{
                    sigmaEl.classList.add('warning');
                    zscoreBox.classList.add('warning');
                }} else {{
                    sigmaEl.classList.add('danger');
                    zscoreBox.classList.add('danger');
                }}
            }} else {{
                sigmaEl.textContent = '-';
            }}
            
            // Anomaly count
            const anomalyEl = document.getElementById('anomalyCount');
            anomalyEl.textContent = data.anomaly_count || 0;
            anomalyEl.className = 'stat-value';
            if (data.anomaly_count === 0) {{
                anomalyEl.classList.add('good');
            }} else if (data.anomaly_count <= 2) {{
                anomalyEl.classList.add('warning');
            }} else {{
                anomalyEl.classList.add('danger');
            }}
            
            // SPC Zone
            const spcZoneEl = document.getElementById('spcZone');
            const spcZone = data.spc_zone || '-';
            spcZoneEl.textContent = spcZone;
            spcZoneEl.className = 'stat-value';
            if (spcZone === 'OutOfControl') {{
                spcZoneEl.classList.add('danger');
                spcZoneEl.textContent = 'Out of Control';
            }} else if (spcZone === 'A') {{
                spcZoneEl.classList.add('warning');
            }} else if (spcZone === 'C' || spcZone === 'B') {{
                spcZoneEl.classList.add('good');
            }}
            
            // SPC Violations
            const violationsDiv = document.getElementById('spcViolations');
            const violations = data.spc_violations || '';
            const isDegenerate = data.is_degenerate || false;
            const degenerateType = data.degenerate_type || '';
            
            if (violations) {{
                violationsDiv.style.display = 'flex';
                document.getElementById('spcViolationsText').textContent = violations;
            }} else if (isDegenerate) {{
                violationsDiv.style.display = 'flex';
                violationsDiv.style.background = '#e3f2fd';
                violationsDiv.style.color = '#1565c0';
                const typeLabel = degenerateType === 'ceiling' ? 'Ceiling (100%)' : 
                                  degenerateType === 'floor' ? 'Floor (0)' : 'Constant';
                document.getElementById('spcViolationsText').textContent = `Zero-variance KPI (${{typeLabel}}) - Rule-based judgment`;
            }} else {{
                violationsDiv.style.display = 'none';
            }}
            
            // Judgment area
            const judgmentArea = document.getElementById('judgmentArea');
            const judgmentText = document.getElementById('judgmentText');
            judgmentArea.style.display = 'flex';
            
            const history = data.history || [];
            if (severity === 'NoHistory' || history.length <= 1) {{
                judgmentArea.className = 'judgment-area judgment-warning';
                judgmentText.innerHTML = '⚠️ <b>No History Data</b> - Cannot compare trends, need more data';
            }} else if (isDegenerate) {{
                // Degenerate case: use rule-based judgment display
                if (severity === 'Normal') {{
                    judgmentArea.className = 'judgment-area judgment-normal';
                    judgmentText.innerHTML = '✅ <b>Normal (Stable)</b> - ' + (data.reasons || 'Constant value maintained');
                }} else if (severity === 'Suspicious') {{
                    judgmentArea.className = 'judgment-area judgment-warning';
                    judgmentText.innerHTML = '⚠️ <b>Suspicious</b> - ' + (data.reasons || 'Value deviation detected (rule-based)');
                }} else if (severity === 'Regression') {{
                    judgmentArea.className = 'judgment-area judgment-abnormal';
                    judgmentText.innerHTML = '❌ <b>Regression</b> - ' + (data.reasons || 'Significant deviation (rule-based)');
                }}
            }} else if (severity === 'Normal') {{
                judgmentArea.className = 'judgment-area judgment-normal';
                judgmentText.innerHTML = '✅ <b>Normal</b> - Current mean is within historical ±2σ range';
            }} else if (severity === 'Suspicious') {{
                judgmentArea.className = 'judgment-area judgment-warning';
                judgmentText.innerHTML = '⚠️ <b>Suspicious</b> - ' + (data.reasons || 'Beyond ±2σ but within ±3σ');
            }} else if (severity === 'Regression') {{
                judgmentArea.className = 'judgment-area judgment-abnormal';
                judgmentText.innerHTML = '❌ <b>Regression</b> - ' + (data.reasons || 'Beyond ±3σ or trending deviation');
            }}
            
            // Draw chart based on current type
            if (currentChartType === 'detail') {{
                drawDetailChart(code, data);
            }} else if (currentChartType === 'spc') {{
                showSPCChart(code);
            }} else if (currentChartType === 'both') {{
                drawDetailChart(code, data);
                showSPCChart(code);
                // Resize after drawing
                setTimeout(() => {{
                    chart && chart.resize();
                    spcChart && spcChart.resize();
                }}, 50);
            }}
        }}
        
        function drawDetailChart(code, data) {{
            const history = data.history || [];
            // Filter out empty history entries for chart (but keep for table)
            const chartHistory = history.filter(h => h.values && h.values.length > 0);
            
            if (chartHistory.length === 0) {{
                chart.setOption({{
                    title: {{
                        text: 'No Data Available',
                        left: 'center',
                        top: 'center',
                        textStyle: {{ color: '#999' }}
                    }}
                }}, true);
                // Still show the data table even if no chart data
                updateDataTable(code, data);
                return;
            }}
            
            const seriesData = [];
            const legendItems = [];
            
            // Find max points for X-axis
            let maxPoints = 0;
            chartHistory.forEach(h => {{
                if (h.values && h.values.length > maxPoints) maxPoints = h.values.length;
            }});
            
            // X-axis labels
            const xLabels = [];
            for (let i = 0; i < maxPoints; i++) {{
                xLabels.push('Point_' + (i + 1));
            }}
            
            // Add confidence interval bands if history stats available
            if (data.hist_stats && data.hist_stats.upper_2sigma !== null) {{
                const upper = data.hist_stats.upper_2sigma;
                const lower = data.hist_stats.lower_2sigma;
                const mean = data.hist_stats.mean;
                
                // Upper boundary
                seriesData.push({{
                    name: 'History +2σ',
                    type: 'line',
                    data: Array(maxPoints).fill(upper),
                    lineStyle: {{ color: '#81C784', type: 'dashed', width: 1 }},
                    itemStyle: {{ color: '#81C784' }},
                    symbol: 'none',
                    silent: true
                }});
                
                // Lower boundary with area
                seriesData.push({{
                    name: 'History -2σ',
                    type: 'line',
                    data: Array(maxPoints).fill(lower),
                    lineStyle: {{ color: '#81C784', type: 'dashed', width: 1 }},
                    itemStyle: {{ color: '#81C784' }},
                    symbol: 'none',
                    areaStyle: {{
                        color: 'rgba(129, 199, 132, 0.15)',
                        origin: 'start'
                    }},
                    silent: true
                }});
                
                // History mean line
                seriesData.push({{
                    name: 'History Mean',
                    type: 'line',
                    data: Array(maxPoints).fill(mean),
                    lineStyle: {{ color: '#4CAF50', type: 'solid', width: 2 }},
                    itemStyle: {{ color: '#4CAF50' }},
                    symbol: 'none',
                    silent: true
                }});
            }}
            
            // Add all historical series (including current)
            chartHistory.forEach((h, idx) => {{
                const isCurrent = h.is_current;
                const color = isCurrent ? '#1976D2' : colors[Math.min(idx, colors.length - 2)];
                const lineWidth = isCurrent ? 3 : 1.5;
                const opacity = isCurrent ? 1 : 0.6;
                
                // Prepare data points (mark anomalies)
                let seriesValues = (h.values || []).map((v, i) => {{
                    if (isCurrent && data.anomaly_indices && data.anomaly_indices.includes(i)) {{
                        return {{
                            value: v,
                            itemStyle: {{ color: '#f44336', borderColor: '#f44336', borderWidth: 2 }},
                            symbolSize: 12
                        }};
                    }}
                    return v;
                }});
                
                seriesData.push({{
                    name: h.label,
                    type: 'line',
                    data: seriesValues,
                    lineStyle: {{
                        width: lineWidth,
                        color: color,
                        opacity: opacity
                    }},
                    itemStyle: {{
                        color: color,
                        opacity: opacity
                    }},
                    symbol: 'circle',
                    symbolSize: isCurrent ? 8 : 5,
                    emphasis: {{
                        focus: 'series',
                        lineStyle: {{ width: 3 }},
                        itemStyle: {{ borderWidth: 2, borderColor: '#333' }}
                    }}
                }});
                
                legendItems.push({{
                    label: h.label,
                    timestamp: h.timestamp,
                    color: color,
                    cv: h.cv,
                    consistency: h.consistency,
                    isCurrent: isCurrent,
                    values: h.values
                }});
            }});
            
            // Update data table (includes all history, even NULL entries)
            updateDataTable(code, data);
            
            // Chart options with improved tooltip showing all series values
            const option = {{
                tooltip: {{
                    trigger: 'axis',
                    formatter: function(params) {{
                        const pointIdx = params[0].dataIndex;
                        let html = `<b>${{params[0].axisValue}}</b><br/>`;
                        params.forEach(p => {{
                            if (p.value !== undefined && p.value !== null) {{
                                const val = typeof p.value === 'object' ? p.value.value : p.value;
                                if (val !== undefined && val !== null) {{
                                    html += `<span style="color:${{p.color}}">●</span> ${{p.seriesName}}: <b>${{typeof val === 'number' ? val.toFixed(4) : val}}</b><br/>`;
                                }}
                            }}
                        }});
                        return html;
                    }}
                }},
                grid: {{
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    top: '10%',
                    containLabel: true
                }},
                xAxis: {{
                    type: 'category',
                    data: xLabels,
                    axisLine: {{ lineStyle: {{ color: '#ddd' }} }},
                    axisLabel: {{ color: '#666' }}
                }},
                yAxis: {{
                    type: 'value',
                    axisLine: {{ show: false }},
                    splitLine: {{ lineStyle: {{ color: '#eee' }} }},
                    axisLabel: {{ color: '#666' }}
                }},
                series: seriesData
            }};
            
            chart.setOption(option, true);
        }}
        
        function updateDataTable(code, data) {{
            const history = data.history || [];
            if (history.length === 0) {{
                document.getElementById('legendItems').innerHTML = '<div style="color: #999; padding: 10px;">No data available</div>';
                return;
            }}
            
            // Find max data points for columns
            let maxPoints = 0;
            history.forEach(h => {{
                if (h.raw_values && h.raw_values.length > maxPoints) maxPoints = h.raw_values.length;
            }});
            
            // Get anomaly indices for current data
            const anomalyIndices = data.anomaly_indices || [];
            
            // Build table header - highlight anomaly columns
            let headerHtml = '<th class="filename">Filename</th><th>CV Value</th>';
            for (let i = 0; i < maxPoints; i++) {{
                const isAnomalyCol = anomalyIndices.includes(i);
                headerHtml += `<th class="${{isAnomalyCol ? 'anomaly-header' : ''}}">Data_${{i + 1}}${{isAnomalyCol ? ' ⚠' : ''}}</th>`;
            }}
            
            // Build table rows
            let rowsHtml = '';
            history.forEach((h, idx) => {{
                const isCurrent = h.is_current;
                const color = isCurrent ? '#1976D2' : colors[Math.min(idx, colors.length - 2)];
                const rowClass = isCurrent ? 'current' : '';
                const cvClass = h.consistency === 'OK' ? 'cv-ok' : (h.consistency === 'NULL' || h.consistency === '-') ? 'cv-null' : 'cv-ng';
                
                // CV display with consistency
                const cvDisplay = h.cv !== null ? `${{h.cv.toFixed(2)}}% (${{h.consistency}})` : `NULL (${{h.consistency}})`;
                
                let rowHtml = `<tr class="${{rowClass}}">`;
                rowHtml += `<td class="filename" title="${{h.label}}">
                    <span style="display: inline-block; width: 12px; height: 12px; background: ${{color}}; border-radius: 2px; margin-right: 6px; vertical-align: middle;"></span>
                    ${{h.label}}${{isCurrent ? ' ← Current' : ''}}
                </td>`;
                rowHtml += `<td class="${{cvClass}}">${{cvDisplay}}</td>`;
                
                // Data values - highlight anomaly cells for current row
                for (let i = 0; i < maxPoints; i++) {{
                    const val = h.raw_values && h.raw_values[i] !== undefined ? h.raw_values[i] : null;
                    const isAnomaly = isCurrent && anomalyIndices.includes(i);
                    if (val !== null) {{
                        rowHtml += `<td class="${{isAnomaly ? 'anomaly-cell' : ''}}">${{typeof val === 'number' ? val.toFixed(4) : val}}</td>`;
                    }} else {{
                        rowHtml += `<td class="cv-null">NULL</td>`;
                    }}
                }}
                rowHtml += '</tr>';
                rowsHtml += rowHtml;
            }});
            
            // Update legend area with table
            document.getElementById('legendItems').innerHTML = `
                <div class="data-table-container">
                    <table class="data-table">
                        <thead><tr>${{headerHtml}}</tr></thead>
                        <tbody>${{rowsHtml}}</tbody>
                    </table>
                </div>
            `;
        }}
        
        function showSPCChart(code) {{
            const data = kpiData[code];
            if (!data) return;
            
            const shewhart = data.shewhart_chart;
            
            if (!shewhart || !shewhart.batch_values || shewhart.batch_values.length < 2) {{
                spcChart.setOption({{
                    title: {{
                        text: 'SPC Control Chart (X-bar)',
                        subtext: 'Need at least 2 historical batches to display',
                        left: 'center',
                        top: 'center',
                        textStyle: {{ color: '#999' }}
                    }}
                }}, true);
                return;
            }}
            
            const batchLabels = shewhart.batch_labels || [];
            const batchValues = shewhart.batch_values || [];
            const zones = shewhart.zones || [];
            const ucl = shewhart.ucl;
            const uwl = data.hist_mean !== null && data.hist_std !== null ? data.hist_mean + 2 * data.hist_std : null;
            const cl = shewhart.cl;
            const lwl = data.hist_mean !== null && data.hist_std !== null ? data.hist_mean - 2 * data.hist_std : null;
            const lcl = shewhart.lcl;
            
            // Prepare data points with zone colors
            const pointData = batchValues.map((v, i) => {{
                const zone = zones[i] || 'C';
                let color = '#4CAF50';
                let symbolSize = 10;
                
                if (zone === 'OutOfControl') {{
                    color = '#f44336';
                    symbolSize = 14;
                }} else if (zone === 'A') {{
                    color = '#FF9800';
                    symbolSize = 12;
                }} else if (zone === 'B') {{
                    color = '#FFC107';
                }}
                
                const isCurrent = i === batchValues.length - 1;
                
                return {{
                    value: v,
                    itemStyle: {{ color: color, borderWidth: isCurrent ? 3 : 1, borderColor: isCurrent ? '#1976D2' : color }},
                    symbolSize: isCurrent ? symbolSize + 4 : symbolSize,
                    label: {{ show: isCurrent, formatter: v.toFixed(2), position: 'top', fontWeight: 'bold' }}
                }};
            }});
            
            const option = {{
                title: {{
                    text: 'SPC Control Chart (X-bar)',
                    subtext: 'Each point represents one test batch mean',
                    left: 'center'
                }},
                tooltip: {{
                    trigger: 'axis',
                    formatter: function(params) {{
                        const idx = params[0].dataIndex;
                        const zone = zones[idx] || '-';
                        let html = `<b>${{batchLabels[idx]}}</b><br/>`;
                        html += `Mean: <b>${{batchValues[idx].toFixed(4)}}</b><br/>`;
                        html += `Zone: <span style="color: ${{zone === 'OutOfControl' ? '#f44336' : zone === 'A' ? '#FF9800' : '#4CAF50'}}">${{zone}}</span>`;
                        return html;
                    }}
                }},
                grid: {{
                    left: '10%',
                    right: '10%',
                    bottom: '15%',
                    top: '15%'
                }},
                xAxis: {{
                    type: 'category',
                    data: batchLabels,
                    axisLabel: {{
                        rotate: 30,
                        fontSize: 10
                    }}
                }},
                yAxis: {{
                    type: 'value',
                    axisLine: {{ show: true }},
                    splitLine: {{ lineStyle: {{ color: '#eee' }} }}
                }},
                series: [
                    {{
                        name: 'Batch Mean',
                        type: 'line',
                        data: pointData,
                        lineStyle: {{ color: '#1976D2', width: 2 }},
                        symbol: 'circle'
                    }},
                    {{
                        name: 'UCL (+3σ)',
                        type: 'line',
                        data: Array(batchValues.length).fill(ucl),
                        lineStyle: {{ color: '#f44336', type: 'dashed', width: 2 }},
                        symbol: 'none',
                        label: {{ show: true, position: 'right', formatter: 'UCL', color: '#f44336' }}
                    }},
                    {{
                        name: 'UWL (+2σ)',
                        type: 'line',
                        data: Array(batchValues.length).fill(uwl),
                        lineStyle: {{ color: '#FF9800', type: 'dotted', width: 1.5 }},
                        symbol: 'none'
                    }},
                    {{
                        name: 'CL (Mean)',
                        type: 'line',
                        data: Array(batchValues.length).fill(cl),
                        lineStyle: {{ color: '#4CAF50', type: 'solid', width: 2 }},
                        symbol: 'none',
                        label: {{ show: true, position: 'right', formatter: 'CL', color: '#4CAF50' }}
                    }},
                    {{
                        name: 'LWL (-2σ)',
                        type: 'line',
                        data: Array(batchValues.length).fill(lwl),
                        lineStyle: {{ color: '#FF9800', type: 'dotted', width: 1.5 }},
                        symbol: 'none'
                    }},
                    {{
                        name: 'LCL (-3σ)',
                        type: 'line',
                        data: Array(batchValues.length).fill(lcl),
                        lineStyle: {{ color: '#f44336', type: 'dashed', width: 2 }},
                        symbol: 'none',
                        label: {{ show: true, position: 'right', formatter: 'LCL', color: '#f44336' }}
                    }}
                ]
            }};
            
            spcChart.setOption(option, true);
        }}
        
        // Filter functions
        function filterList() {{
            const keyword = document.getElementById('searchBox').value.toLowerCase();
            document.querySelectorAll('.kpi-item').forEach(item => {{
                const code = item.dataset.code;
                const data = kpiData[code];
                const codeLower = code.toLowerCase();
                const kpiName = (data?.kpi_name || '').toLowerCase();
                const severity = item.dataset.severity || '';
                const type = item.dataset.type || '';
                const consistency = data?.consistency || '';
                const anomalyCount = data?.anomaly_count || 0;
                
                let visible = codeLower.includes(keyword) || kpiName.includes(keyword);
                
                // Severity filter
                if (visible && currentSeverityFilter !== 'all') {{
                    visible = severity === currentSeverityFilter;
                }}
                
                // Type filter
                if (visible && currentTypeFilter !== 'all') {{
                    if (currentTypeFilter === 'KPI') {{
                        visible = isKPICode(code);
                    }} else if (currentTypeFilter === 'Counter') {{
                        visible = isCounterCode(code);
                    }}
                }}
                
                // Advanced filters
                if (visible && advancedFilters.hasAnomaly) {{
                    const threshold = advancedFilters.anomalyThreshold;
                    if (threshold === -1) {{
                        // All Anomaly: all data points are anomalies
                        const kData = kpiData[code];
                        const totalPoints = kData?.total_points || 0;
                        visible = totalPoints > 0 && anomalyCount >= totalPoints;
                    }} else {{
                        visible = anomalyCount >= threshold;
                    }}
                }}
                if (visible && advancedFilters.excludeNull) {{
                    visible = consistency !== 'NULL' && consistency.toLowerCase() !== 'null';
                }}
                if (visible && advancedFilters.excludePartialNull) {{
                    visible = !consistency.toLowerCase().includes('partial') && !consistency.toLowerCase().includes('null');
                }}
                if (visible && advancedFilters.onlyInconsistent) {{
                    visible = consistency === 'Inconsistent' || consistency === 'NG';
                }}
                
                item.style.display = visible ? 'flex' : 'none';
            }});
            
            // Update visible count in severity groups
            updateVisibleCounts();
            
            // Auto-select if only one item visible
            const visibleItems = Array.from(document.querySelectorAll('.kpi-item')).filter(
                item => item.style.display !== 'none'
            );
            if (visibleItems.length === 1) {{
                showChart(visibleItems[0].dataset.code);
            }}
        }}
        
        function updateVisibleCounts() {{
            document.querySelectorAll('.severity-group').forEach(group => {{
                const visibleItems = group.querySelectorAll('.kpi-item[style*="flex"], .kpi-item:not([style*="display"])').length;
                const header = group.querySelector('.severity-header');
                if (header) {{
                    const originalText = header.textContent.split('(')[0].trim();
                    const totalItems = group.querySelectorAll('.kpi-item').length;
                    header.textContent = `${{originalText}} (${{visibleItems}}/${{totalItems}})`;
                }}
            }});
        }}
        
        // Anomaly filter dropdown functions
        function toggleAnomalyDropdown(event) {{
            event.stopPropagation();
            const dropdown = document.getElementById('anomalyDropdown');
            dropdown.classList.toggle('show');
            
            // Update counts in dropdown
            updateAnomalyFilterCounts();
        }}
        
        function setAnomalyThreshold(threshold) {{
            advancedFilters.anomalyThreshold = threshold;
            advancedFilters.hasAnomaly = threshold !== 0;
            
            // Update chip display
            const chip = document.getElementById('anomalyFilterChip');
            if (threshold === 0) {{
                chip.textContent = 'Anomaly (off) ';
                chip.classList.remove('active');
            }} else if (threshold === -1) {{
                chip.innerHTML = 'All Anomaly ⚠️ <span class="shortcut-hint">(N)</span>';
                chip.classList.add('active');
            }} else {{
                chip.innerHTML = `Anomaly ≥${{threshold}} <span class="shortcut-hint">(N)</span>`;
                chip.classList.add('active');
            }}
            
            // Update dropdown active state
            document.querySelectorAll('.anomaly-dropdown-item').forEach(item => {{
                item.classList.remove('active');
            }});
            event.target.classList.add('active');
            
            // Close dropdown
            document.getElementById('anomalyDropdown').classList.remove('show');
            
            filterList();
        }}
        
        function updateAnomalyFilterCounts() {{
            let count1 = 0;  // Has at least 1 anomaly
            let countAll = 0;  // All points are anomalies
            
            Object.keys(kpiData).forEach(code => {{
                const data = kpiData[code];
                const anomalyCount = data.anomaly_count || 0;
                
                if (anomalyCount >= 1) count1++;
                
                // Check if all points are anomalies
                const totalPoints = data.total_points || 0;
                if (totalPoints > 0 && anomalyCount >= totalPoints) {{
                    countAll++;
                }}
            }});
            
            const count1El = document.getElementById('anomalyCount1');
            const countAllEl = document.getElementById('anomalyCountAll');
            if (count1El) count1El.textContent = `(${{count1}})`;
            if (countAllEl) countAllEl.textContent = `(${{countAll}})`;
        }}
        
        function cycleAnomalyFilter() {{
            // Cycle: 0 (off) → 1 (≥1) → -1 (all anomaly) → 0 (off)
            const currentThreshold = advancedFilters.anomalyThreshold;
            let newThreshold;
            
            if (currentThreshold === 0) {{
                newThreshold = 1;  // off → ≥1
            }} else if (currentThreshold === 1) {{
                newThreshold = -1;  // ≥1 → all anomaly
            }} else {{
                newThreshold = 0;  // all anomaly → off
            }}
            
            advancedFilters.anomalyThreshold = newThreshold;
            advancedFilters.hasAnomaly = newThreshold !== 0;
            
            // Update chip display
            const chip = document.getElementById('anomalyFilterChip');
            if (newThreshold === 0) {{
                chip.innerHTML = 'Anomaly (off) <span class="shortcut-hint">(N)</span>';
                chip.classList.remove('active');
            }} else if (newThreshold === -1) {{
                chip.innerHTML = 'All Anomaly ⚠️ <span class="shortcut-hint">(N)</span>';
                chip.classList.add('active');
            }} else {{
                chip.innerHTML = `Anomaly ≥${{newThreshold}} <span class="shortcut-hint">(N)</span>`;
                chip.classList.add('active');
            }}
            
            // Update dropdown active state
            document.querySelectorAll('.anomaly-dropdown-item').forEach(item => {{
                const itemThreshold = parseInt(item.dataset.threshold);
                item.classList.toggle('active', itemThreshold === newThreshold);
            }});
            
            filterList();
        }}
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {{
            const dropdown = document.getElementById('anomalyDropdown');
            const container = document.querySelector('.anomaly-filter-container');
            if (dropdown && container && !container.contains(e.target)) {{
                dropdown.classList.remove('show');
            }}
        }});
        
        function toggleAdvancedFilter(filterName) {{
            advancedFilters[filterName] = !advancedFilters[filterName];
            
            // Update UI
            const chip = document.querySelector(`[data-filter="${{filterName}}"]`);
            if (chip) {{
                chip.classList.toggle('active', advancedFilters[filterName]);
            }}
            
            filterList();
        }}
        
        function filterBySeverity(severity) {{
            currentSeverityFilter = severity;
            
            document.querySelectorAll('.summary-item').forEach(btn => btn.classList.remove('active'));
            
            if (severity === 'all') {{
                document.querySelector('.summary-item.all').classList.add('active');
            }} else if (severity === 'Regression') {{
                document.querySelector('.summary-item.regression').classList.add('active');
            }} else if (severity === 'Suspicious') {{
                document.querySelector('.summary-item.suspicious').classList.add('active');
            }} else if (severity === 'Normal') {{
                document.querySelector('.summary-item.normal').classList.add('active');
            }} else if (severity === 'NoHistory') {{
                document.querySelector('.summary-item.no-history').classList.add('active');
            }}
            
            filterList();
        }}
        
        function filterByType(type) {{
            currentTypeFilter = type;
            
            document.querySelectorAll('.type-btn').forEach(btn => btn.classList.remove('active'));
            
            if (type === 'all') {{
                document.querySelector('.type-btn.all').classList.add('active');
            }} else if (type === 'KPI') {{
                document.querySelector('.type-btn.kpi').classList.add('active');
            }} else if (type === 'Counter') {{
                document.querySelector('.type-btn.counter').classList.add('active');
            }}
            
            filterList();
        }}
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {{
            if (e.target.tagName === 'INPUT') {{
                if (e.key === 'Escape') {{
                    e.target.blur();
                }}
                return;
            }}
            
            switch(e.key.toLowerCase()) {{
                case '/':
                    e.preventDefault();
                    document.getElementById('searchBox').focus();
                    break;
                case 'k':
                    filterByType('KPI');
                    break;
                case 'c':
                    filterByType('Counter');
                    break;
                case 'a':
                    filterByType('all');
                    break;
                case '1':
                    switchChartType('detail');
                    break;
                case '2':
                    switchChartType('spc');
                    break;
                case '3':
                    switchChartType('both');
                    break;
                case 'n':
                    // Cycle through anomaly filter: off → ≥1 → all anomaly → off
                    cycleAnomalyFilter();
                    break;
                case 'x':
                    toggleAdvancedFilter('excludeNull');
                    break;
                case 'p':
                    toggleAdvancedFilter('excludePartialNull');
                    break;
                case 'i':
                    toggleAdvancedFilter('onlyInconsistent');
                    break;
                case 'h':
                    showHelp();
                    break;
                case 'arrowdown':
                    e.preventDefault();
                    navigateList(1);
                    break;
                case 'arrowup':
                    e.preventDefault();
                    navigateList(-1);
                    break;
                case 'enter':
                    // Select current item if navigating
                    const activeItem = document.querySelector('.kpi-item.active');
                    if (activeItem) {{
                        showChart(activeItem.dataset.code);
                    }}
                    break;
            }}
        }});
        
        // Navigate through visible KPI list items
        function navigateList(direction) {{
            const visibleItems = Array.from(document.querySelectorAll('.kpi-item')).filter(
                item => item.style.display !== 'none'
            );
            if (visibleItems.length === 0) return;
            
            const currentActive = document.querySelector('.kpi-item.active');
            let currentIndex = currentActive ? visibleItems.indexOf(currentActive) : -1;
            
            // Calculate new index
            let newIndex = currentIndex + direction;
            if (newIndex < 0) newIndex = visibleItems.length - 1;
            if (newIndex >= visibleItems.length) newIndex = 0;
            
            // Select new item
            const newItem = visibleItems[newIndex];
            if (newItem) {{
                showChart(newItem.dataset.code);
                // Scroll into view
                newItem.scrollIntoView({{ behavior: 'smooth', block: 'nearest' }});
            }}
        }}
        
        function showHelp() {{
            alert(`Keyboard Shortcuts:
            
Navigation:
↑/↓ - Navigate KPI list
Enter - Select current item
/ - Focus search box

Type Filters:
K - Filter KPI only
C - Filter Counter only  
A - Show all types

Chart Views:
1 - Data Detail Chart
2 - SPC Control Chart
3 - Both Charts (side by side)

Advanced Filters:
N - Has Anomaly (keep only items with anomaly count > 0)
X - Exclude NULL (hide NULL data)
P - Exclude Partial NULL (hide partial null data)
I - Only Inconsistent (show only CV inconsistent items)

Visual Indicators in KPI List:
● Green dot - Consistent (CV OK)
● Red dot - Inconsistent (CV NG)
○ Gray dot - NULL data
A:n - Anomaly count badge

H - Show this help
M - Manage history records`);
        }}
        
        // History Management Functions
        let historyRecords = [];
        let selectedHistoryIndices = new Set();
        
        function openHistoryModal() {{
            // Populate history list from kpiData
            populateHistoryList();
            document.getElementById('historyModal').classList.add('active');
        }}
        
        function closeHistoryModal() {{
            document.getElementById('historyModal').classList.remove('active');
            document.getElementById('commandOutput').classList.remove('show');
        }}
        
        function populateHistoryList() {{
            // Extract history records from kpiData
            historyRecords = [];
            const seen = new Set();
            
            // Get the first KPI that has history data
            for (const code in kpiData) {{
                const data = kpiData[code];
                if (data.history && data.history.length > 0) {{
                    data.history.forEach(h => {{
                        const key = h.timestamp || h.label;
                        if (!seen.has(key)) {{
                            seen.add(key);
                            historyRecords.push({{
                                timestamp: h.timestamp,
                                label: h.label,
                                is_current: h.is_current,
                                index: historyRecords.length
                            }});
                        }}
                    }});
                    break;  // Only need history from one KPI
                }}
            }}
            
            // Sort by timestamp (oldest first)
            historyRecords.sort((a, b) => {{
                if (a.timestamp && b.timestamp) {{
                    return a.timestamp.localeCompare(b.timestamp);
                }}
                return 0;
            }});
            
            // Render list
            const listEl = document.getElementById('historyList');
            if (historyRecords.length === 0) {{
                listEl.innerHTML = '<div style="color:#999; padding:20px; text-align:center;">No history records found</div>';
                return;
            }}
            
            listEl.innerHTML = historyRecords.map((h, idx) => `
                <div class="history-item ${{h.is_current ? 'current' : ''}}" data-index="${{idx}}">
                    <input type="checkbox" class="history-checkbox" id="hist_${{idx}}" 
                           onchange="toggleHistorySelection(${{idx}})" ${{h.is_current ? 'disabled' : ''}}>
                    <div class="history-info">
                        <div class="history-filename">${{h.label}}</div>
                        <div class="history-time">${{h.timestamp || 'No timestamp'}}</div>
                    </div>
                    ${{h.is_current ? '<span class="history-badge current">Current</span>' : ''}}
                </div>
            `).join('');
            
            updateSelectedCount();
        }}
        
        function toggleHistorySelection(idx) {{
            if (selectedHistoryIndices.has(idx)) {{
                selectedHistoryIndices.delete(idx);
            }} else {{
                selectedHistoryIndices.add(idx);
            }}
            updateSelectedCount();
        }}
        
        function selectAllHistory() {{
            historyRecords.forEach((h, idx) => {{
                if (!h.is_current) {{
                    selectedHistoryIndices.add(idx);
                    const checkbox = document.getElementById(`hist_${{idx}}`);
                    if (checkbox) checkbox.checked = true;
                }}
            }});
            updateSelectedCount();
        }}
        
        function deselectAllHistory() {{
            selectedHistoryIndices.clear();
            historyRecords.forEach((h, idx) => {{
                const checkbox = document.getElementById(`hist_${{idx}}`);
                if (checkbox) checkbox.checked = false;
            }});
            updateSelectedCount();
        }}
        
        function updateSelectedCount() {{
            document.getElementById('selectedCount').textContent = `${{selectedHistoryIndices.size}} selected`;
        }}
        
        function generateDeleteCommand() {{
            if (selectedHistoryIndices.size === 0) {{
                alert('Please select at least one record to delete');
                return;
            }}
            
            // Get selected timestamps
            const timestamps = [];
            selectedHistoryIndices.forEach(idx => {{
                const record = historyRecords[idx];
                if (record && record.timestamp) {{
                    timestamps.push(record.timestamp);
                }}
            }});
            
            if (timestamps.length === 0) {{
                alert('Selected records have no valid timestamps');
                return;
            }}
            
            // Generate command
            const commands = timestamps.map(ts => 
                `python scripts/manage_history.py --delete "${{ts}}"`
            ).join('\\n');
            
            const fullCommand = `# Run in project directory (251224_KPI_consistency)\\n# To delete ${{timestamps.length}} selected record(s):\\n\\n${{commands}}\\n\\n# Or use interactive mode:\\npython scripts/manage_history.py --interactive`;
            
            // Show command
            const outputEl = document.getElementById('commandOutput');
            outputEl.textContent = fullCommand;
            outputEl.classList.add('show');
            
            // Copy to clipboard
            navigator.clipboard.writeText(commands).then(() => {{
                alert(`Command copied to clipboard!\\n\\nRun in terminal to delete ${{timestamps.length}} record(s).\\nAfter deletion, re-run analysis to update reports.`);
            }}).catch(err => {{
                console.error('Failed to copy: ', err);
                alert('Command generated! Please copy it manually from the output area below.');
            }});
        }}
        
        // Add M keyboard shortcut
        document.addEventListener('keydown', function(e) {{
            if (e.target.tagName === 'INPUT') return;
            if (e.key.toLowerCase() === 'm') {{
                openHistoryModal();
            }}
            if (e.key === 'Escape') {{
                closeHistoryModal();
            }}
        }});
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {{
            initChart();
        }});
    </script>
</body>
</html>
'''
        return html
    
    def _generate_kpi_list_html(self, all_codes_df: pd.DataFrame) -> str:
        """Generate HTML for KPI list grouped by severity"""
        if all_codes_df.empty:
            return '<div class="severity-group"><div class="severity-header" style="background: #999">No Data</div></div>'
        
        severity_order = ['Regression', 'Suspicious', 'Normal', 'NoHistory']
        severity_colors = {
            'Regression': '#f44336',
            'Suspicious': '#FF9800',
            'Normal': '#4CAF50',
            'NoHistory': '#9E9E9E'
        }
        
        html_parts = []
        
        for severity in severity_order:
            subset = all_codes_df[all_codes_df['Severity'] == severity]
            if subset.empty:
                continue
            
            # Sort by sigma level descending
            if 'Sigma_Level' in subset.columns:
                subset = subset.sort_values('Sigma_Level', ascending=False, na_position='last')
            
            color = severity_colors.get(severity, '#999')
            count = len(subset)
            
            items_html = []
            for _, row in subset.iterrows():
                code = row.get('Code', '')
                code_type = row.get('Type', 'Other')
                sigma = row.get('Sigma_Level')
                consistency = row.get('Consistency', '-')
                anomaly_count = row.get('Anomaly_Count', 0)
                total_points = row.get('Total_Points', 0)
                sigma_str = f'σ={sigma:.1f}' if sigma is not None and not np.isnan(sigma) else 'σ=-'
                
                # Add consistency and anomaly indicators
                consistency_indicator = ''
                if 'NULL' in str(consistency).upper():
                    consistency_indicator = '<span style="color:#9e9e9e;font-size:10px;">⚪</span>'
                elif consistency == 'Inconsistent' or consistency == 'NG':
                    consistency_indicator = '<span style="color:#f44336;font-size:10px;">●</span>'
                else:
                    consistency_indicator = '<span style="color:#4caf50;font-size:10px;">●</span>'
                
                anomaly_indicator = ''
                if anomaly_count and anomaly_count > 0:
                    # Check if all points are anomalies
                    if total_points > 0 and anomaly_count >= total_points:
                        anomaly_indicator = f'<span class="all-anomaly-badge" title="All {int(total_points)} points are anomalies">⚠️ ALL</span>'
                    else:
                        anomaly_indicator = f'<span style="color:#f44336;font-size:10px;margin-left:3px;">A:{int(anomaly_count)}</span>'
                
                items_html.append(f'''
                    <div class="kpi-item" onclick="showChart('{code}')" data-code="{code}" data-severity="{severity}" data-type="{code_type}" data-consistency="{consistency}">
                        <span class="code">{consistency_indicator} {code}{anomaly_indicator}</span>
                        <span class="type">[{code_type}] {sigma_str}</span>
                    </div>
                ''')
            
            html_parts.append(f'''
                <div class="severity-group">
                    <div class="severity-header" style="background-color: {color}">
                        {severity} ({count})
                    </div>
                    <div class="severity-items">
                        {"".join(items_html)}
                    </div>
                </div>
            ''')
        
        return "".join(html_parts)
    
    def _calculate_statistics(self, consistency_df: pd.DataFrame, 
                              suspicious_df: pd.DataFrame,
                              all_codes_df: pd.DataFrame) -> Dict[str, int]:
        """Calculate summary statistics"""
        stats = {
            'total': 0,
            'regression': 0,
            'suspicious': 0,
            'normal': 0,
            'nohistory': 0
        }
        
        if not all_codes_df.empty:
            stats['total'] = len(all_codes_df)
            stats['regression'] = int((all_codes_df['Severity'] == 'Regression').sum())
            stats['suspicious'] = int((all_codes_df['Severity'] == 'Suspicious').sum())
            stats['normal'] = int((all_codes_df['Severity'] == 'Normal').sum())
            stats['nohistory'] = int((all_codes_df['Severity'] == 'NoHistory').sum())
        
        return stats
